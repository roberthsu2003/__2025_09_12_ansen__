import { useHighScores } from "@/hooks/use-scores";
import { Loader2, Trophy } from "lucide-react";

export function HighScoreBoard() {
  const { data: scores, isLoading } = useHighScores();

  return (
    <div className="w-full max-w-md bg-slate-900/80 border-2 border-slate-800 p-6 relative overflow-hidden">
      {/* Decorative corners */}
      <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-primary"></div>
      <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-primary"></div>
      <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-primary"></div>
      <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-primary"></div>

      <div className="flex items-center gap-3 mb-6 border-b border-slate-800 pb-4">
        <Trophy className="text-yellow-500 w-6 h-6" />
        <h3 className="font-arcade text-xl text-white tracking-widest">HIGH SCORES</h3>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="animate-spin text-primary w-8 h-8" />
        </div>
      ) : scores && scores.length > 0 ? (
        <ul className="space-y-3">
          {scores.sort((a, b) => b.score - a.score).slice(0, 10).map((entry, index) => (
            <li 
              key={entry.id} 
              className={`flex justify-between items-center font-arcade text-sm py-2 px-3 border border-transparent ${
                index === 0 ? 'bg-yellow-500/10 border-yellow-500/30 text-yellow-400' : 
                index === 1 ? 'bg-slate-500/10 border-slate-500/30 text-slate-300' :
                index === 2 ? 'bg-amber-700/10 border-amber-700/30 text-amber-600' :
                'text-slate-400'
              }`}
            >
              <div className="flex gap-4">
                <span className="opacity-50 w-6">#{index + 1}</span>
                <span>{entry.username}</span>
              </div>
              <span className="text-white">{entry.score.toLocaleString()}</span>
            </li>
          ))}
        </ul>
      ) : (
        <div className="text-center py-8 text-slate-600 font-arcade text-xs">
          NO SCORES YET. BE THE FIRST!
        </div>
      )}
    </div>
  );
}
