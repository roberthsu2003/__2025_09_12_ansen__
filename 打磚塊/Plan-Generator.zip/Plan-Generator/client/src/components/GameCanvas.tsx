import { useEffect, useRef, useState, useCallback } from "react";
import { CONSTANTS, Ball, Paddle, Brick } from "../game/types";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { useSubmitScore } from "@/hooks/use-scores";
import { useToast } from "@/hooks/use-toast";
import confetti from "canvas-confetti";
import { motion, AnimatePresence } from "framer-motion";
import { Play, RotateCcw, Trophy } from "lucide-react";

type GameState = "MENU" | "PLAYING" | "GAME_OVER" | "VICTORY";

export function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const requestRef = useRef<number>();
  const { toast } = useToast();

  // Game Logic State Refs (Mutable for performance in loop)
  const paddleRef = useRef<Paddle>(new Paddle());
  const ballRef = useRef<Ball>(new Ball(CONSTANTS.SCREEN_WIDTH / 2, CONSTANTS.SCREEN_HEIGHT - 100));
  const bricksRef = useRef<Brick[]>([]);
  
  // React State for UI
  const [gameState, setGameState] = useState<GameState>("MENU");
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(CONSTANTS.PLAYER_LIVES);
  const [username, setUsername] = useState("");
  
  const submitScoreMutation = useSubmitScore();

  // Initialize Bricks
  const initBricks = useCallback(() => {
    const newBricks: Brick[] = [];
    const offsetX = (CONSTANTS.SCREEN_WIDTH - (CONSTANTS.BRICK_COLS * (CONSTANTS.BRICK_WIDTH + CONSTANTS.BRICK_PADDING))) / 2;
    
    for (let r = 0; r < CONSTANTS.BRICK_ROWS; r++) {
      for (let c = 0; c < CONSTANTS.BRICK_COLS; c++) {
        const x = offsetX + c * (CONSTANTS.BRICK_WIDTH + CONSTANTS.BRICK_PADDING);
        const y = CONSTANTS.BRICK_TOP_OFFSET + r * (CONSTANTS.BRICK_HEIGHT + CONSTANTS.BRICK_PADDING);
        newBricks.push(new Brick(x, y));
      }
    }
    bricksRef.current = newBricks;
  }, []);

  const resetGame = useCallback(() => {
    setScore(0);
    setLives(CONSTANTS.PLAYER_LIVES);
    paddleRef.current = new Paddle();
    ballRef.current.reset();
    initBricks();
    setGameState("PLAYING");
  }, [initBricks]);

  const handleGameOver = useCallback(() => {
    setGameState("GAME_OVER");
    if (requestRef.current) cancelAnimationFrame(requestRef.current);
  }, []);

  const handleVictory = useCallback(() => {
    setGameState("VICTORY");
    if (requestRef.current) cancelAnimationFrame(requestRef.current);
    confetti({
      particleCount: 150,
      spread: 70,
      origin: { y: 0.6 },
      colors: [CONSTANTS.COLORS.RED, CONSTANTS.COLORS.BLUE, CONSTANTS.COLORS.GREEN]
    });
  }, []);

  const submitHighScore = async () => {
    if (!username.trim()) {
      toast({ title: "Enter a name!", variant: "destructive" });
      return;
    }
    try {
      await submitScoreMutation.mutateAsync({ username, score });
      toast({ title: "Score saved!", className: "bg-green-600 text-white" });
      setGameState("MENU");
    } catch (e) {
      toast({ title: "Failed to save score", variant: "destructive" });
    }
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== "PLAYING") return;
      if (e.key === "ArrowLeft") paddleRef.current.move("left");
      if (e.key === "ArrowRight") paddleRef.current.move("right");
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [gameState]);

  // Main Game Loop
  const update = useCallback(() => {
    if (gameState !== "PLAYING") return;

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (!canvas || !ctx) return;

    // Clear Canvas
    ctx.fillStyle = CONSTANTS.COLORS.BACKGROUND;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const ball = ballRef.current;
    const paddle = paddleRef.current;
    const bricks = bricksRef.current;

    // --- Physics ---
    
    // Move ball
    ball.x += ball.dx;
    ball.y += ball.dy;

    // Wall collisions
    if (ball.x + ball.radius > canvas.width || ball.x - ball.radius < 0) {
      ball.dx = -ball.dx;
    }
    if (ball.y - ball.radius < 0) {
      ball.dy = -ball.dy;
    }
    
    // Paddle collision
    if (
      ball.y + ball.radius > paddle.y &&
      ball.x > paddle.x &&
      ball.x < paddle.x + paddle.width
    ) {
      ball.dy = -ball.dy;
      // Add some "english" based on where it hit the paddle
      const hitPoint = ball.x - (paddle.x + paddle.width / 2);
      ball.dx = hitPoint * 0.15; 
    }

    // Floor collision (Life Lost)
    if (ball.y + ball.radius > canvas.height) {
      if (lives > 1) {
        setLives(l => l - 1);
        ball.reset();
      } else {
        setLives(0);
        handleGameOver();
        return; // Stop loop for this frame
      }
    }

    // Brick collision
    let activeBricks = 0;
    bricks.forEach(brick => {
      if (brick.active) {
        activeBricks++;
        if (
          ball.x > brick.x &&
          ball.x < brick.x + brick.width &&
          ball.y > brick.y &&
          ball.y < brick.y + brick.height
        ) {
          ball.dy = -ball.dy;
          brick.active = false;
          setScore(s => s + CONSTANTS.SCORE_PER_BRICK);
        }
      }
    });

    if (activeBricks === 0) {
      handleVictory();
      return;
    }

    // --- Drawing ---
    paddle.draw(ctx);
    ball.draw(ctx);
    bricks.forEach(brick => brick.draw(ctx));

    requestRef.current = requestAnimationFrame(update);
  }, [gameState, lives, handleGameOver, handleVictory]);

  // Start/Stop Loop
  useEffect(() => {
    if (gameState === "PLAYING") {
      requestRef.current = requestAnimationFrame(update);
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState, update]);

  // Mouse Movement
  const handleMouseMove = (e: React.MouseEvent) => {
    if (gameState !== "PLAYING" || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const scaleX = canvasRef.current.width / rect.width;
    const mouseX = (e.clientX - rect.left) * scaleX;
    paddleRef.current.moveTo(mouseX);
  };

  // Initial draw for menu background
  useEffect(() => {
    if (gameState === "MENU" && canvasRef.current) {
      const ctx = canvasRef.current.getContext("2d");
      if (ctx) {
        ctx.fillStyle = CONSTANTS.COLORS.BACKGROUND;
        ctx.fillRect(0, 0, CONSTANTS.SCREEN_WIDTH, CONSTANTS.SCREEN_HEIGHT);
        // Draw some static demo elements
        initBricks();
        bricksRef.current.forEach(b => b.draw(ctx));
        paddleRef.current.draw(ctx);
      }
    }
  }, [gameState, initBricks]);

  return (
    <div className="relative group rounded-xl overflow-hidden shadow-2xl shadow-primary/20 border-4 border-slate-800 bg-black">
      {/* HUD */}
      <div className="absolute top-4 left-6 z-10 font-arcade text-white text-lg flex gap-8 pointer-events-none drop-shadow-md">
        <span className="text-primary">SCORE: {score.toString().padStart(5, '0')}</span>
        <span className="text-secondary">LIVES: {"♥".repeat(lives)}</span>
      </div>

      <canvas
        ref={canvasRef}
        width={CONSTANTS.SCREEN_WIDTH}
        height={CONSTANTS.SCREEN_HEIGHT}
        onMouseMove={handleMouseMove}
        className="block bg-slate-900 cursor-none w-full h-auto max-w-[800px] aspect-[4/3]"
        style={{ imageRendering: "pixelated" }}
      />

      {/* OVERLAYS */}
      <AnimatePresence>
        {gameState === "MENU" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-8 backdrop-blur-sm scanlines"
          >
            <h1 className="text-6xl font-arcade text-transparent bg-clip-text bg-gradient-to-b from-primary to-purple-600 mb-8 animate-pulse text-center leading-relaxed py-2">
              NEON<br/>BREAKOUT
            </h1>
            <Button
              size="lg"
              onClick={resetGame}
              className="text-xl px-10 py-8 font-arcade bg-secondary text-black hover:bg-secondary/80 hover:scale-105 transition-all shadow-[0_0_20px_rgba(0,255,255,0.5)] border-none rounded-none"
            >
              <Play className="mr-4 w-6 h-6" /> PRESS START
            </Button>
            <p className="mt-8 text-slate-400 font-sans text-sm uppercase tracking-widest">
              Use Mouse or Arrow Keys to Move
            </p>
          </motion.div>
        )}

        {(gameState === "GAME_OVER" || gameState === "VICTORY") && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center p-8 backdrop-blur-md z-20"
          >
            <h2 className={`text-5xl font-arcade mb-4 ${gameState === "VICTORY" ? "text-accent animate-bounce" : "text-destructive"}`}>
              {gameState === "VICTORY" ? "YOU WIN!" : "GAME OVER"}
            </h2>
            
            <div className="bg-slate-800/50 p-6 rounded border border-slate-700 w-full max-w-sm mb-6 text-center">
              <p className="text-slate-400 font-arcade text-sm mb-2">FINAL SCORE</p>
              <p className="text-4xl text-white font-arcade">{score}</p>
            </div>

            <div className="w-full max-w-sm space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="ENTER INITIALS"
                  maxLength={3}
                  className="bg-black border-slate-700 text-center font-arcade uppercase text-xl h-12 tracking-widest text-primary focus:border-primary"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toUpperCase())}
                />
                <Button 
                  onClick={submitHighScore}
                  disabled={submitScoreMutation.isPending}
                  className="h-12 w-12 p-0 rounded bg-primary hover:bg-primary/80"
                >
                  <Trophy className="w-5 h-5" />
                </Button>
              </div>
              
              <Button
                variant="outline"
                onClick={resetGame}
                className="w-full h-12 font-arcade text-white border-slate-600 hover:bg-slate-800 hover:text-white rounded-none"
              >
                <RotateCcw className="mr-2 w-4 h-4" /> TRY AGAIN
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
