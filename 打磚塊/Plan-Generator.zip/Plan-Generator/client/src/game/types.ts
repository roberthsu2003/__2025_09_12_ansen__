export const CONSTANTS = {
  SCREEN_WIDTH: 800,
  SCREEN_HEIGHT: 600,
  PADDLE_WIDTH: 100,
  PADDLE_HEIGHT: 15,
  PADDLE_Y_OFFSET: 40,
  PADDLE_SPEED: 8,
  BALL_RADIUS: 8,
  BALL_SPEED: 5, // Base speed, can increase
  BRICK_ROWS: 5,
  BRICK_COLS: 10,
  BRICK_PADDING: 5,
  BRICK_TOP_OFFSET: 60,
  BRICK_WIDTH: 70, // Will be calculated dynamically to fit if needed, but using spec
  BRICK_HEIGHT: 25,
  PLAYER_LIVES: 3,
  SCORE_PER_BRICK: 10,
  COLORS: {
    RED: '#ff0055',    // Primary / Ball
    BLUE: '#00ffff',   // Secondary / Paddle
    GREEN: '#00ff66',  // Accent / Bricks
    WHITE: '#ffffff',
    BACKGROUND: '#0a0a0f'
  }
};

export interface GameObject {
  x: number;
  y: number;
  color: string;
  draw(ctx: CanvasRenderingContext2D): void;
}

export class Ball implements GameObject {
  x: number;
  y: number;
  dx: number;
  dy: number;
  radius: number;
  color: string;
  active: boolean = true;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.dx = CONSTANTS.BALL_SPEED * (Math.random() > 0.5 ? 1 : -1);
    this.dy = -CONSTANTS.BALL_SPEED;
    this.radius = CONSTANTS.BALL_RADIUS;
    this.color = CONSTANTS.COLORS.RED;
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (!this.active) return;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
    
    // Glow effect
    ctx.shadowBlur = 15;
    ctx.shadowColor = this.color;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.closePath();
  }

  reset() {
    this.x = CONSTANTS.SCREEN_WIDTH / 2;
    this.y = CONSTANTS.SCREEN_HEIGHT - 100;
    this.dx = CONSTANTS.BALL_SPEED * (Math.random() > 0.5 ? 1 : -1);
    this.dy = -CONSTANTS.BALL_SPEED;
  }
}

export class Paddle implements GameObject {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  color: string;

  constructor() {
    this.width = CONSTANTS.PADDLE_WIDTH;
    this.height = CONSTANTS.PADDLE_HEIGHT;
    this.x = (CONSTANTS.SCREEN_WIDTH - this.width) / 2;
    this.y = CONSTANTS.SCREEN_HEIGHT - CONSTANTS.PADDLE_Y_OFFSET;
    this.speed = CONSTANTS.PADDLE_SPEED;
    this.color = CONSTANTS.COLORS.BLUE;
  }

  draw(ctx: CanvasRenderingContext2D) {
    ctx.beginPath();
    ctx.rect(this.x, this.y, this.width, this.height);
    ctx.fillStyle = this.color;
    ctx.fill();
    
    // Glow effect
    ctx.shadowBlur = 20;
    ctx.shadowColor = this.color;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.closePath();
  }

  move(direction: 'left' | 'right') {
    if (direction === 'left') {
      this.x -= this.speed;
      if (this.x < 0) this.x = 0;
    } else {
      this.x += this.speed;
      if (this.x + this.width > CONSTANTS.SCREEN_WIDTH) {
        this.x = CONSTANTS.SCREEN_WIDTH - this.width;
      }
    }
  }

  moveTo(x: number) {
    this.x = x - this.width / 2;
    // Clamp to screen
    if (this.x < 0) this.x = 0;
    if (this.x + this.width > CONSTANTS.SCREEN_WIDTH) {
      this.x = CONSTANTS.SCREEN_WIDTH - this.width;
    }
  }
}

export class Brick implements GameObject {
  x: number;
  y: number;
  width: number;
  height: number;
  active: boolean;
  color: string;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.width = CONSTANTS.BRICK_WIDTH;
    this.height = CONSTANTS.BRICK_HEIGHT;
    this.active = true;
    this.color = CONSTANTS.COLORS.GREEN;
  }

  draw(ctx: CanvasRenderingContext2D) {
    if (!this.active) return;
    ctx.beginPath();
    ctx.rect(this.x, this.y, this.width, this.height);
    ctx.fillStyle = this.color;
    ctx.fill();
    
    // Inner bevel for 3D effect
    ctx.strokeStyle = 'rgba(255,255,255,0.3)';
    ctx.lineWidth = 2;
    ctx.strokeRect(this.x, this.y, this.width, this.height);
    
    // Slight glow
    ctx.shadowBlur = 5;
    ctx.shadowColor = this.color;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.closePath();
  }
}
