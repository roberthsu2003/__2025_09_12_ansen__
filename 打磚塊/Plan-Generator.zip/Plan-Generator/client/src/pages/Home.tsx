import { GameCanvas } from "@/components/GameCanvas";
import { HighScoreBoard } from "@/components/HighScoreBoard";
import { Gamepad2 } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col items-center p-4 md:p-8 overflow-x-hidden scanlines">
      {/* Header */}
      <header className="w-full max-w-7xl flex justify-between items-center mb-8 border-b-2 border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-primary rounded shadow-[0_0_15px_rgba(255,0,85,0.6)]">
            <Gamepad2 className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-arcade text-white tracking-widest drop-shadow-[0_2px_0_rgba(0,0,0,1)]">
              ARCADE<span className="text-secondary">LABS</span>
            </h1>
            <p className="text-xs text-slate-500 font-arcade mt-1">EST. 2024</p>
          </div>
        </div>
        <div className="hidden md:block text-right">
          <p className="text-sm text-slate-400 font-mono">SYSTEM READY</p>
          <div className="flex gap-2 mt-1">
            <span className="w-3 h-3 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(0,255,0,0.8)]"></span>
            <span className="w-3 h-3 bg-slate-700 rounded-full"></span>
            <span className="w-3 h-3 bg-slate-700 rounded-full"></span>
          </div>
        </div>
      </header>

      {/* Main Content Layout */}
      <main className="w-full max-w-7xl grid lg:grid-cols-[1fr_350px] gap-8 items-start">
        
        {/* Left Column: Game Canvas */}
        <section className="flex flex-col items-center">
          <GameCanvas />
          
          <div className="w-full mt-6 bg-slate-900/50 border border-slate-800 p-4 rounded text-center">
            <p className="font-arcade text-xs text-slate-500 mb-2">CONTROLS</p>
            <div className="flex justify-center gap-8 text-sm font-sans text-slate-300">
              <span className="flex items-center gap-2">
                <kbd className="px-2 py-1 bg-slate-800 rounded border border-slate-700 font-mono">←</kbd>
                <kbd className="px-2 py-1 bg-slate-800 rounded border border-slate-700 font-mono">→</kbd>
                MOVE
              </span>
              <span className="flex items-center gap-2">
                <span className="px-2 py-1 bg-slate-800 rounded border border-slate-700">MOUSE</span>
                AIM
              </span>
            </div>
          </div>
        </section>

        {/* Right Column: High Scores & Info */}
        <aside className="space-y-6 w-full flex flex-col items-center lg:items-stretch">
          <HighScoreBoard />
          
          <div className="w-full max-w-md bg-gradient-to-br from-secondary/10 to-transparent border border-secondary/20 p-6 rounded relative overflow-hidden group">
            <div className="absolute inset-0 bg-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <h3 className="font-arcade text-secondary text-sm mb-2">PRO TIP</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Hitting the ball with the edge of the paddle adds spin and changes the angle dramatically. Use it to reach tricky bricks!
            </p>
          </div>

          <footer className="text-center text-slate-600 text-xs py-8 font-mono">
            &copy; 2024 RETRO BREAKOUT
          </footer>
        </aside>

      </main>
    </div>
  );
}
