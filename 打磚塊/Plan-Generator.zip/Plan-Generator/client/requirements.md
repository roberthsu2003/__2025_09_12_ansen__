## Packages
framer-motion | Smooth animations for UI overlays and game states
canvas-confetti | Victory celebration effects

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  arcade: ['"Press Start 2P"', "cursive"],
  sans: ["var(--font-sans)"],
}
